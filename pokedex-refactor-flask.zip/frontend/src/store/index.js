import configureStore from './store';

export default configureStore;
